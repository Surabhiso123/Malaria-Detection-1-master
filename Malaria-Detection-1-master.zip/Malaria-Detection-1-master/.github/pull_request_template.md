<!--
Thank you for sending the PR! We appreciate you spending the time to work on these changes.
please fill out the following.
Happy Contributing!
-->

### Have you read the [Contributing Guidelines on Pull Requests](https://github.com/HakinCodes/Malaria-Detection/blob/master/CONTRIBUTING.md)?

(Write your answer here.)

### Description

(Write your answer here.)

### Checklist

- [ ] I've read the contribution guidelines.
- [ ] This PR meets all the requirements like Clean Code, proper README and Documentation.

### Related Issues or Pull Requests

Fixes: #[Issue number that will be closed through this PR] 
<!---
Example - Fixes: #21 
-->

### Screenshots (if any)

 Original           | Updated
 :--------------------: |:--------------------:
 **original screenshot** | **updated screenshot**|
